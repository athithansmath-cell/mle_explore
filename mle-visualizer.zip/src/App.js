import React, { useState, useEffect } from "react";
import { LineChart, Line, XAxis, YAxis, Tooltip, CartesianGrid, ReferenceDot } from "recharts";

const distributions = ["Poisson", "Exponential", "Normal", "Uniform", "Geometric", "Binomial"];

export default function App() {
  const [dist, setDist] = useState("Poisson");
  const [data, setData] = useState("2,3,4,2,1");
  const [graphData, setGraphData] = useState([]);
  const [mle, setMLE] = useState(0);

  const values = data.split(",").map(Number);

  useEffect(() => {
    if (!values.length) return;

    let graph = [];
    let mleVal = 0;

    if (dist === "Poisson") {
      mleVal = values.reduce((a, b) => a + b, 0) / values.length;
      for (let l = 0.1; l < mleVal * 2; l += 0.1) {
        let logL = -values.length * l + values.reduce((a, b) => a + b, 0) * Math.log(l);
        graph.push({ x: l, logL });
      }
    }

    if (dist === "Exponential") {
      mleVal = 1 / (values.reduce((a, b) => a + b, 0) / values.length);
      for (let l = 0.1; l < mleVal * 3; l += 0.1) {
        let logL = values.length * Math.log(l) - l * values.reduce((a, b) => a + b, 0);
        graph.push({ x: l, logL });
      }
    }

    if (dist === "Normal") {
      mleVal = values.reduce((a, b) => a + b, 0) / values.length;
      for (let m = mleVal - 3; m <= mleVal + 3; m += 0.1) {
        let logL = values.reduce((sum, x) => sum - (x - m) ** 2, 0);
        graph.push({ x: m, logL });
      }
    }

    if (dist === "Uniform") {
      mleVal = Math.max(...values);
      for (let b = mleVal; b <= mleVal + 5; b += 0.2) {
        let logL = -values.length * Math.log(b);
        graph.push({ x: b, logL });
      }
    }

    if (dist === "Geometric") {
      mleVal = 1 / (values.reduce((a, b) => a + b, 0) / values.length);
      for (let p = 0.01; p < 1; p += 0.02) {
        let logL =
          values.length * Math.log(p) +
          (values.reduce((a, b) => a + b, 0) - values.length) * Math.log(1 - p);
        graph.push({ x: p, logL });
      }
    }

    if (dist === "Binomial") {
      let n = Math.max(...values);
      mleVal = values.reduce((a, b) => a + b, 0) / (n * values.length);
      for (let p = 0.01; p < 1; p += 0.02) {
        let logL = values.reduce(
          (sum, x) => sum + x * Math.log(p) + (n - x) * Math.log(1 - p),
          0
        );
        graph.push({ x: p, logL });
      }
    }

    setGraphData(graph);
    setMLE(mleVal);
  }, [data, dist]);

  return (
    <div className="container">
      <div className="left">
        <h2>MLE Visualizer</h2>

        <select value={dist} onChange={(e) => setDist(e.target.value)}>
          {distributions.map((d) => (
            <option key={d}>{d}</option>
          ))}
        </select>

        <input value={data} onChange={(e) => setData(e.target.value)} />

        <p><b>MLE:</b> {mle.toFixed(4)}</p>
      </div>

      <div className="right">
        <LineChart width={700} height={400} data={graphData}>
          <CartesianGrid strokeDasharray="3 3" />
          <XAxis dataKey="x" />
          <YAxis />
          <Tooltip />
          <Line type="monotone" dataKey="logL" />

          <ReferenceDot
            x={mle}
            y={Math.max(...graphData.map((d) => d.logL || 0))}
            r={6}
          />
        </LineChart>
      </div>
    </div>
  );
}
