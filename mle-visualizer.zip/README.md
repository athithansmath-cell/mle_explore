# MLE Visualizer

Interactive Maximum Likelihood Estimation tool.

## Run locally
npm install
npm start

## Deploy
Use Vercel
